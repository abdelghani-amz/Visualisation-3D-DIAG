<template>
  <div>
    <v-checkbox
    v-if="addCheckbox == 'true'"
    label = "Afficher"
    @change="toggleDisplay"
    input-value="true"
    ></v-checkbox>
    <v-slider
      v-if="addCheckbox == 'true'"
      label="Opacité"
      max="1"
      min="0"
      step = "0.05"
      color="white"
      :disabled = "disabled"
      :value="opacity"
      @input="getAlpha"
    ></v-slider>
    <v-slider
      label="R"
      max="1"
      min="0"
      step = "0.01"
      color="red"
      :value = "red"
      :disabled = "disabled"
      @input="getRed"
    ></v-slider>
    <v-slider
      label="G"
      max="1"
      min="0"
      step = "0.01"
      color="green"
      :value = "green"
      :disabled = "disabled"
      @input="getGreen"
    ></v-slider>
    <v-slider
      label="B"
      max="1"
      min="0"
      step = "0.01"
      color="blue"
      :value = "blue"
      :disabled = "disabled"
      @input="getBlue"
       
    ></v-slider>
  </div>
    
</template>

<script>
  export default {
    name: 'Menue',
    props : ["red", "green", "blue", "opacity", "addCheckbox"],
    data: () => ({ 
      disabled: false ,
      R: null, 
      G : null,
      B: null,
      A: null
      }),
    methods: {
      getRed(value){
        this.R = value
        this.$emit("rgba-change", this.R, this.G, this.B, this.A, !(this.disabled))
      },
      getBlue(value){
        this.B = value
        this.$emit("rgba-change", this.R, this.G, this.B, this.A, !(this.disabled))
      },
      getGreen(value){
        this.G = value
        this.$emit("rgba-change", this.R, this.G, this.B, this.A, !(this.disabled))        
      },
      getAlpha(value){
        this.A = value
        this.$emit("rgba-change", this.R, this.G, this.B, this.A, !(this.disabled))
      },
      toggleDisplay(){
        this.disabled = !this.disabled
        this.$emit("rgba-change", this.R, this.G, this.B, this.A, !(this.disabled))
      }
    },
    created(){
      this.R = parseInt(this.red)
      this.G = parseInt(this.green)
      this.B = parseInt(this.blue)
      this.A = parseInt(this.opacity)
    }
    
  }
</script>